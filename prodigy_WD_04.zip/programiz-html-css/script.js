// Add any interactive functionality here (animations, toggles, etc.)
console.log("Portfolio site loaded!");
